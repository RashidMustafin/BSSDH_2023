This dataset provide the TEI/XML that represents the texts and associated metadata created by the 
Manuscript Pamphleteering in Early Stuart England project (https://mpese.ac.uk) 

The data is copyright © University of Birmingham and University of Bristol, 2017–2018 and 
are provided under a Creative Commons Attribution 4.0 International (CC BY 4.0) licence.

The top level directories:

mss/ (1477 XML files describing MSS in repositories)
texts/ (535 XML describing texts and providing transcripts)
people/ (1 XML describing 17th century authors, scribes etc.)

These can be open in a standard text editor, e.g. TextEdit (MacOS), Notepad (Windows).